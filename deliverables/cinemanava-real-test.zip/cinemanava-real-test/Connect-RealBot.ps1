# Local, temporary connection test. Never puts credentials in process arguments.
# Does not read, rename, or overwrite .env and does not send anything to Arena/GitHub.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$node = Get-Command node.exe -ErrorAction SilentlyContinue
if (-not $node) {
    [System.Windows.Forms.MessageBox]::Show('Install Node.js LTS from nodejs.org, then run this test again.', 'Node.js is missing') | Out-Null
    exit 1
}
$appFile = Join-Path $PSScriptRoot 'movie-server.js'
if (-not (Test-Path -LiteralPath $appFile -PathType Leaf)) {
    $picker = New-Object System.Windows.Forms.OpenFileDialog
    $picker.Title = 'Choose movie-server.js from your EXTRACTED cinemanava folder'
    $picker.Filter = 'CinemaNava server (movie-server.js)|movie-server.js'
    $picker.InitialDirectory = Join-Path $env:USERPROFILE 'Downloads'
    if ($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { $picker.Dispose(); exit 0 }
    $appFile = $picker.FileName
    $picker.Dispose()
}
$appFolder = Split-Path -Parent $appFile
if ((Split-Path -Leaf $appFile) -ne 'movie-server.js' -or -not (Test-Path -LiteralPath (Join-Path $appFolder 'src\moviebot\service.js'))) {
    [System.Windows.Forms.MessageBox]::Show('Choose movie-server.js from the extracted CinemaNava application, not from inside a ZIP.', 'Wrong folder') | Out-Null
    exit 1
}
Set-Location -LiteralPath $appFolder
if (-not (Test-Path -LiteralPath (Join-Path $appFolder 'node_modules\dotenv'))) {
    $npm = Get-Command npm.cmd -ErrorAction SilentlyContinue
    if (-not $npm) { throw 'npm is missing. Install Node.js LTS.' }
    & $npm.Source ci
    if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Check internet access.' }
}
# Avoid accidentally opening an old demo server on a different port.
$portInUse = Get-NetTCPConnection -LocalPort 3030 -State Listen -ErrorAction SilentlyContinue
if ($portInUse) {
    [System.Windows.Forms.MessageBox]::Show('Port 3030 is already in use. Close the previous TEST window before running a second test. No process was stopped automatically.', 'Test already running') | Out-Null
    exit 1
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'CinemaNava - REAL Telegram connection test'
$form.ClientSize = New-Object System.Drawing.Size(570, 395)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.Font = New-Object System.Drawing.Font('Segoe UI', 10)
function Add-Label($text, $x, $y, $width, $height) {
    $label = New-Object System.Windows.Forms.Label
    $label.Text = $text
    $label.Location = New-Object System.Drawing.Point($x, $y)
    $label.Size = New-Object System.Drawing.Size($width, $height)
    $form.Controls.Add($label)
}
function Add-Input($y, $secret) {
    $field = New-Object System.Windows.Forms.TextBox
    $field.Location = New-Object System.Drawing.Point(24, $y)
    $field.Size = New-Object System.Drawing.Size(520, 28)
    $field.UseSystemPasswordChar = $secret
    $form.Controls.Add($field)
    return $field
}
Add-Label 'Enter secrets ONLY here on your laptop. Do not send screenshots.' 24 18 520 24
Add-Label '1. BotFather token for @newmoveonbot (hidden)' 24 54 520 23
$tokenBox = Add-Input 79 $true
Add-Label '2. NEW panel password - at least 12 characters (hidden)' 24 119 520 23
$passwordBox = Add-Input 144 $true
Add-Label '3. Your numeric Telegram admin ID (optional; leave blank for now)' 24 184 520 23
$adminBox = Add-Input 209 $false
Add-Label 'Temporary test only. Does not save these values in .env.' 24 252 520 22
Add-Label 'Local test panel: http://127.0.0.1:3030 (not port 3000)' 24 276 520 22
$errorLabel = New-Object System.Windows.Forms.Label
$errorLabel.Location = New-Object System.Drawing.Point(24, 305)
$errorLabel.Size = New-Object System.Drawing.Size(520, 27)
$errorLabel.ForeColor = [System.Drawing.Color]::Firebrick
$form.Controls.Add($errorLabel)
$startButton = New-Object System.Windows.Forms.Button
$startButton.Text = 'Start REAL test'
$startButton.Location = New-Object System.Drawing.Point(350, 344)
$startButton.Size = New-Object System.Drawing.Size(194, 33)
$startButton.Add_Click({
    if ($tokenBox.Text.Trim() -notmatch '^\d+:[A-Za-z0-9_-]{20,}$') { $errorLabel.Text = 'Enter the full bot token from BotFather.'; return }
    if ($passwordBox.Text.Length -lt 12 -or $passwordBox.Text.Length -gt 128) { $errorLabel.Text = 'Choose a panel password with 12-128 characters.'; return }
    if ($adminBox.Text.Trim() -and $adminBox.Text.Trim() -notmatch '^\d+(,\d+)*$') { $errorLabel.Text = 'Admin ID must be numeric, or leave it empty.'; return }
    $form.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $form.Close()
})
$form.Controls.Add($startButton)
$form.AcceptButton = $startButton
if ($form.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { $form.Dispose(); exit 0 }

# Explicit process environment overrides any broken/missing .env for this test.
# Inherited by node, never passed as command-line arguments and never logged.
$names = @('TELEGRAM_BOT_TOKEN','MOVIEBOT_ADMIN_PASSWORD','TELEGRAM_ADMIN_IDS','MOVIEBOT_AUTOSTART','HOST','PORT')
$previous = @{}
foreach ($name in $names) { $previous[$name] = [Environment]::GetEnvironmentVariable($name, 'Process') }
$exitCode = 0
try {
    $env:TELEGRAM_BOT_TOKEN = $tokenBox.Text.Trim()
    $env:MOVIEBOT_ADMIN_PASSWORD = $passwordBox.Text
    $env:TELEGRAM_ADMIN_IDS = $adminBox.Text.Trim()
    $env:MOVIEBOT_AUTOSTART = 'true'
    $env:HOST = '127.0.0.1'
    $env:PORT = '3030'
    $tokenBox.Clear(); $passwordBox.Clear(); $adminBox.Clear(); $form.Dispose()
    Write-Host ''
    Write-Host 'REAL MODE requested. Live Telegram connectivity is not yet confirmed.'
    Write-Host 'Open http://127.0.0.1:3030 and use the NEW password you just chose.'
    Write-Host 'The panel status must say running before testing the bot in Telegram.'
    Write-Host 'Keep this console open. Ctrl+C stops the server.'
    & $node.Source $appFile
    $exitCode = $LASTEXITCODE
}
finally {
    foreach ($name in $names) { [Environment]::SetEnvironmentVariable($name, $previous[$name], 'Process') }
    if (-not $form.IsDisposed) { $tokenBox.Clear(); $passwordBox.Clear(); $form.Dispose() }
}
exit $exitCode

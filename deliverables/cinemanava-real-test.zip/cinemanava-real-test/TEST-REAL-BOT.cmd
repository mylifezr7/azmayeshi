@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0Connect-RealBot.ps1" (
 echo Extract BOTH files from the test ZIP into a normal folder first.
 pause
 exit /b 1
)
echo CinemaNava real connection test. Credentials are entered in a local window.
echo No token or password is written to this console or sent to Arena/GitHub.
powershell.exe -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Connect-RealBot.ps1"
echo.
echo Test stopped. Its credentials were not saved by this launcher.
pause

#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Install Node.js LTS from https://nodejs.org"; exit 1; }
if [ ! -f .env ]; then
 cp .env.example .env
 echo "Edit .env privately: TELEGRAM_BOT_TOKEN and MOVIEBOT_ADMIN_PASSWORD, then rerun."
 exit 0
fi
if [ ! -d node_modules/dotenv ]; then npm ci; fi
npm start

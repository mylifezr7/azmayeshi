require('dotenv').config({ quiet: true });
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { Store } = require('./src/moviebot/store');
const { Telegram } = require('./src/moviebot/telegram');
const { MovieBot } = require('./src/moviebot/service');
const { createHandler } = require('./src/moviebot/http');
const { serveDownload } = require('./src/moviebot/download');
const password = process.env.MOVIEBOT_ADMIN_PASSWORD || '';
if (password && password.length < 12) throw Error('MOVIEBOT_ADMIN_PASSWORD must contain at least 12 characters.');
const demo = !password;
const token = process.env.TELEGRAM_BOT_TOKEN || '';
const store = new Store(path.join(__dirname, 'data', demo ? 'moviebot-demo.json' : 'moviebot.json'), demo);
const bot = new MovieBot(store, new Telegram(token), { demo, configured: !!password && !!token,
  adminIds: (process.env.TELEGRAM_ADMIN_IDS || '').split(',').map(s => s.trim()).filter(s => /^\d+$/.test(s)) });
const handler = createHandler(store, bot);
const files = { '/': 'moviebot.html', '/moviebot': 'moviebot.html', '/moviebot.html': 'moviebot.html', '/moviebot.css': 'moviebot.css', '/moviebot.js': 'moviebot.js' };
const server = http.createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' https:; connect-src 'self'; base-uri 'none'; form-action 'self'; object-src 'none'");
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (await serveDownload(req, res, url.pathname, __dirname)) return;
    if (await handler(req, res, url)) return;
    if (req.method === 'GET' && url.pathname === '/api/health') { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ ok: true, service: 'moviebot', demo, running: bot.running })); return; }
    const asset = /^\/movie-assets\/[a-z]+\.svg$/.test(url.pathname) ? url.pathname.slice(1) : files[url.pathname];
    if (req.method !== 'GET' || !asset) { res.writeHead(404); res.end('Not found'); return; }
    const file = path.join(__dirname, 'public', asset), ext = path.extname(file);
    fs.readFile(file, (err, value) => { if (err) { res.writeHead(404); res.end('Not found'); return; } res.writeHead(200, { 'Content-Type': ({ '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript', '.svg': 'image/svg+xml' })[ext], 'Cache-Control': 'no-cache' }); res.end(value); });
  } catch { if (!res.headersSent) res.writeHead(500); res.end('Server error'); }
});
const port = Number(process.env.PORT || 3000);
const host = process.env.HOST || '0.0.0.0';
if (!['127.0.0.1', '0.0.0.0'].includes(host)) throw Error('HOST must be 127.0.0.1 or 0.0.0.0.');
server.listen(port, host, () => {
  console.log(`CinemaNava dashboard on ${host}:${port} (${demo ? 'DEMO: Telegram requests disabled' : 'admin login required'})`);
  if (!demo && process.env.MOVIEBOT_AUTOSTART === 'true') bot.start().catch(e => console.error(e.message));
});
function shutdown() { bot.close(); server.close(); setTimeout(() => process.exit(0), 1000).unref(); }
process.on('SIGTERM', shutdown); process.on('SIGINT', shutdown);

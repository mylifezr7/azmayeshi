const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs'); const os = require('node:os'); const path = require('node:path'); const http = require('node:http');
const { Store } = require('../src/moviebot/store');
const { MovieBot } = require('../src/moviebot/service');
const { TelegramError, isMember } = require('../src/moviebot/telegram');
const { createHandler } = require('../src/moviebot/http');
function fixture(t, { demo = false, reply } = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cinemanava-'));
  const store = new Store(path.join(dir, 'db.json'), demo), calls = [];
  const api = { async call(method, body) { calls.push({ method, body }); if (reply) return reply(method, body); if (method === 'getChatMember') return { status: 'member' }; if (method === 'getMe') return { username: 'TestMovieBot' }; if (method === 'getWebhookInfo') return { url: '' }; return { message_id: 12, chat: { id: -1001234567890 } }; } };
  const bot = new MovieBot(store, api, { demo, configured: true, adminIds: ['99'] });
  t.after(() => { bot.close(); fs.rmSync(dir, { recursive: true, force: true }); });
  store.data.settings = { ...store.data.settings, botUsername: 'TestMovieBot', publishChannel: '@moviechannel', channels: [{ title: 'حامی', chatId: '@sponsorchannel', inviteUrl: 'https://t.me/sponsorchannel' }] };
  store.data.movies = [{ id: 'movie123', title: 'آزمون', year: '2025', description: 'محتوای دارای مجوز', poster: 'https://example.org/poster.jpg', fileId: 'TelegramFileId12345', fileType: 'document', status: 'published', downloads: 0 }];
  return { store, bot, calls, api };
}
const update = (id = 1, text = '/start m_movie123') => ({ update_id: id, message: { chat: { id: 17, type: 'private' }, from: { id: 17, first_name: 'کاربر' }, text } });
test('membership statuses fail closed for left, kicked and restricted nonmembers', () => {
  for (const status of ['member', 'creator', 'administrator']) assert.equal(isMember({ status }), true);
  for (const status of ['left', 'kicked', 'restricted', 'unknown']) assert.equal(isMember({ status }), false);
  assert.equal(isMember({ status: 'restricted', is_member: true }), true);
});
test('deep link delivers only after fresh membership check; duplicate update is not resent', async t => {
  const { bot, calls, store } = fixture(t); await bot.handle(update()); await bot.handle(update());
  assert.deepEqual(calls.map(c => c.method), ['getChatMember', 'sendDocument']);
  assert.equal(store.data.movies[0].downloads, 1); assert.equal(store.data.users[0].downloads, 1);
});
test('nonmember and membership API failure never receive the file', async t => {
  for (const error of [false, true]) {
    const { bot, calls, store } = fixture(t, { reply: method => { if (method === 'getChatMember') { if (error) throw Error('no admin rights'); return { status: 'left' }; } return {}; } });
    await bot.handle(update()); assert.ok(!calls.some(c => c.method === 'sendDocument'));
    const prompt = calls.find(c => c.method === 'sendMessage'); assert.equal(prompt.body.reply_markup.inline_keyboard[0][0].url, 'https://t.me/sponsorchannel'); assert.equal(store.data.movies[0].downloads, 0);
  }
});
test('changing promotional channel takes effect on the next download', async t => {
  const { bot, calls, store } = fixture(t); await bot.handle(update(1));
  store.data.settings.channels[0].chatId = '@newadvertchannel'; await bot.handle(update(2));
  assert.equal(calls.filter(c => c.method === 'getChatMember').at(-1).body.chat_id, '@newadvertchannel');
});
test('blocked users and unpublished movies do not get files', async t => {
  const { bot, calls, store } = fixture(t); store.data.movies[0].status = 'draft'; await bot.handle(update());
  assert.ok(!calls.some(c => c.method === 'sendDocument'));
  store.data.users[0].blocked = true; calls.length = 0; await bot.handle(update(2)); assert.equal(calls.length, 0);
});
test('membership callback rechecks membership before video delivery', async t => {
  const { bot, calls, store } = fixture(t); store.data.movies[0].fileType = 'video';
  await bot.handle({ update_id: 55, callback_query: { id: 'callback', from: { id: 17, first_name: 'Test' }, data: 'check:movie123', message: { chat: { id: 17, type: 'private' } } } });
  assert.deepEqual(calls.map(c => c.method), ['answerCallbackQuery', 'getChatMember', 'sendVideo']);
});
test('only allowlisted admins can register uploaded files', async t => {
  const { bot, store } = fixture(t); const a = update(); a.message.document = { file_id: 'DocumentFileId1234', file_name: 'movie.mp4', file_size: 456 };
  await bot.handle(a); assert.equal(store.data.inbox.length, 0);
  const b = update(2); b.message.from.id = 99; b.message.chat.id = 99; b.message.document = a.message.document;
  await bot.handle(b); assert.equal(store.data.inbox.length, 1); assert.equal(store.data.inbox[0].fileId, 'DocumentFileId1234');
});
test('scheduled publication waits then creates poster with inline download deep link', async t => {
  const { bot, store, calls } = fixture(t); bot.running = true;
  const job = bot.queue('movie123', new Date(Date.now() + 60000).toISOString()); await bot.tick(); assert.equal(calls.length, 0);
  job.runAt = new Date(Date.now() - 1000).toISOString(); await bot.tick();
  assert.equal(job.status, 'sent'); assert.equal(store.data.movies[0].status, 'published');
  assert.equal(calls[0].method, 'sendPhoto'); assert.equal(calls[0].body.reply_markup.inline_keyboard[0][0].url, 'https://t.me/TestMovieBot?start=m_movie123');
});
test('uncertain sends are not automatically retried, including after restart', async t => {
  const { bot, store, calls } = fixture(t, { reply: () => { throw new TelegramError('timeout', true); } }); bot.running = true;
  const job = bot.queue('movie123'); await bot.tick(); await bot.tick(); assert.equal(job.status, 'unknown'); assert.equal(calls.length, 1);
  job.status = 'sending'; store.save(); const recovered = new Store(store.file); assert.equal(recovered.data.jobs[0].status, 'unknown');
});
test('demo publishing never calls the Telegram API', async t => {
  const { bot, store, calls } = fixture(t, { demo: true }); const job = bot.queue('movie123'); await bot.tick();
  assert.equal(job.status, 'demo_sent'); assert.equal(store.data.movies[0].status, 'demo_published'); assert.equal(calls.length, 0);
});
test('live publication rejects missing join-channel configuration', t => {
  const { bot, store } = fixture(t); store.data.settings.channels = []; assert.throws(() => bot.queue('movie123'), /کانال عضویت/);
});
test('HTTP live mode requires login, rejects CSRF, and never exposes the token', async t => {
  const { store, bot } = fixture(t), handler = createHandler(store, bot, { password: 'test-password-long-enough' });
  const server = http.createServer(async (req, res) => { await handler(req, res, new URL(req.url, 'http://localhost')); });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve)); t.after(() => new Promise(resolve => server.close(resolve)));
  const base = `http://127.0.0.1:${server.address().port}/api/moviebot`;
  assert.equal((await fetch(base + '/state')).status, 401);
  assert.equal((await fetch(base + '/login', { method: 'POST' })).status, 403);
  const headers = { 'Content-Type': 'application/json', 'X-Moviebot-Admin': '1' };
  const login = await fetch(base + '/login', { method: 'POST', headers, body: JSON.stringify({ password: 'test-password-long-enough' }) });
  assert.equal(login.status, 200); const cookie = login.headers.get('set-cookie').split(';')[0];
  const response = await fetch(base + '/state', { headers: { Cookie: cookie } }); assert.equal(response.status, 200); const data = await response.json();
  assert.equal('token' in data, false);
  const blocked = await fetch(base + '/settings', { method: 'PUT', headers: { ...headers, Cookie: cookie, Origin: 'https://attacker.example' }, body: '{}' }); assert.equal(blocked.status, 403);
  const settings = await fetch(base + '/settings', { method: 'PUT', headers: { ...headers, Cookie: cookie }, body: JSON.stringify({ ...data.settings, channels: [{ title: 'Ad', chatId: '@advertchannel', inviteUrl: 'javascript:alert(1)' }] }) }); assert.equal(settings.status, 400);
  await fetch(base + '/logout', { method: 'POST', headers: { ...headers, Cookie: cookie }, body: '{}' }); assert.equal((await fetch(base + '/state', { headers: { Cookie: cookie } })).status, 401);
});
test('public download serves only the sanitized archive and supports HEAD', async t => {
  const { serveDownload } = require('../src/moviebot/download');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cinemanava-download-'));
  fs.mkdirSync(path.join(dir, 'deliverables')); const archive = Buffer.from('PK\x03\x04test-zip'); fs.writeFileSync(path.join(dir, 'deliverables/cinemanava-laptop.zip'), archive);
  const server = http.createServer(async (req, res) => { if (!await serveDownload(req, res, req.url, dir)) { res.writeHead(404); res.end(); } });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(async () => { await new Promise(resolve => server.close(resolve)); fs.rmSync(dir, { recursive: true, force: true }); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const get = await fetch(base + '/downloads/cinemanava-laptop.zip'); assert.equal(get.status, 200); assert.equal(get.headers.get('content-type'), 'application/zip'); assert.match(get.headers.get('content-disposition'), /attachment/); assert.deepEqual(Buffer.from(await get.arrayBuffer()), archive);
  const head = await fetch(base + '/downloads/cinemanava-laptop.zip', { method: 'HEAD' }); assert.equal(head.status, 200); assert.equal((await head.arrayBuffer()).byteLength, 0);
  assert.equal((await fetch(base + '/downloads/.env')).status, 404);
  fs.unlinkSync(path.join(dir, 'deliverables/cinemanava-laptop.zip')); assert.equal((await fetch(base + '/downloads/cinemanava-laptop.zip', { method: 'HEAD' })).status, 404);
});

@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Install Node.js LTS from https://nodejs.org and reopen this window.
 pause
 exit /b 1
)
if not exist .env (
 copy .env.example .env >nul
 echo Edit TELEGRAM_BOT_TOKEN and MOVIEBOT_ADMIN_PASSWORD in .env. Never share them.
 start /wait notepad .env
 echo Save .env, then run this launcher again.
 pause
 exit /b 0
)
if not exist node_modules\dotenv (
 call npm.cmd ci
 if errorlevel 1 (
  echo Dependency installation failed. Check your internet connection.
  pause
  exit /b 1
 )
)
echo Open http://127.0.0.1:3000 in your browser after the server starts.
call npm.cmd start
pause

const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const num = n => Number(n || 0).toLocaleString('fa-IR');
const date = value => value ? new Date(value).toLocaleString('fa-IR', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—';
const icon = name => `<svg><use href="#i-${name}"/></svg>`;
const empty = (text, symbol = '▧') => `<div class="empty-state"><span class="empty-icon">${symbol}</span>${esc(text)}</div>`;
const labels = { draft: 'پیش‌نویس', queued: 'در صف', sending: 'در حال ارسال', sent: 'منتشرشده', published: 'منتشرشده', demo_sent: 'انتشار نمایشی', demo_published: 'نمایش آزمایشی', failed: 'ناموفق', unknown: 'نتیجه نامشخص', cancelled: 'لغوشده' };
let state, view = 'overview', toastTimer, refreshing = false;
const views = {
  overview: ['نمای کلی', 'یک نگاه به فیلم‌ها، انتشارها و مخاطب‌های مجموعه‌ات.'],
  library: ['کتابخانهٔ فیلم‌ها', 'آرشیو مرتب؛ از پوستر و توضیحات تا فایل نهایی.'],
  queue: ['انتشار و زمان‌بندی', 'پست بعدی را آماده کن؛ ربات سر وقت منتشرش می‌کند.'],
  channels: ['کانال‌ها و عضویت', 'کانال انتشار و مقصد عضویت تبلیغاتی را از همین‌جا تغییر بده.'],
  users: ['کاربران ربات', 'مخاطب‌ها، دریافت‌ها و دسترسی کاربران.'],
  inbox: ['فایل‌های دریافتی', 'فیلم و پوستر را برای ربات بفرست؛ از اینجا انتخابشان کن.'],
  settings: ['تنظیمات ربات', 'هویت مجموعه، پیام‌ها و نگهداری امن.']
};
function toast(message, error = false) {
  clearTimeout(toastTimer); const el = $('#toast'); el.textContent = message; el.hidden = false; el.classList.toggle('error', error);
  toastTimer = setTimeout(() => { el.hidden = true; }, 6000);
}
async function api(path, method = 'GET', data) {
  const response = await fetch('/api/moviebot' + path, { method, headers: { 'Content-Type': 'application/json', 'X-Moviebot-Admin': '1' }, ...(data !== undefined ? { body: JSON.stringify(data) } : {}) });
  const result = await response.json();
  if (response.status === 401 && path !== '/login') { $('#shell').hidden = true; $('#login-screen').hidden = false; }
  if (!response.ok) throw Error(result.error || 'درخواست انجام نشد.'); return result;
}
async function task(fn, button) {
  if (button?.disabled) return;
  if (button) button.disabled = true;
  try { await fn(); } catch (e) { toast(e.message, true); } finally { if (button) button.disabled = false; }
}
function poster(m) { return /^https:\/\//i.test(m.poster || '') || /^\/movie-assets\/[a-z]+\.svg$/.test(m.poster || '') ? m.poster : '/movie-assets/placeholder.svg'; }
function movieCard(m) {
  return `<article class="movie-card"><div class="poster-wrap"><img loading="lazy" src="${esc(poster(m))}" alt="پوستر ${esc(m.title)}"><span class="movie-tag">${esc(labels[m.status] || m.status)}</span></div><h3>${esc(m.title)}</h3><div class="movie-meta"><span>${esc(m.year || '—')}</span><span>·</span><span>${esc(m.genre || 'بدون ژانر')}</span><span>·</span><span>${esc(m.quality || '—')}</span></div><div class="movie-actions"><button data-action="edit-movie" data-id="${esc(m.id)}">ویرایش</button><button class="movie-publish" data-action="publish" data-id="${esc(m.id)}">انتشار ←</button><button data-action="delete-movie" data-id="${esc(m.id)}" title="حذف فیلم" aria-label="حذف ${esc(m.title)}">×</button></div></article>`;
}
function renderLibrary() {
  const q = $('#movie-search').value.trim().toLowerCase(), filter = $('#movie-filter').value;
  const movies = state.movies.filter(m => m.title.toLowerCase().includes(q) && (filter === 'all' || (filter === 'published' ? ['published', 'demo_published'].includes(m.status) : m.status === filter)));
  $('#library-grid').innerHTML = movies.length ? movies.map(movieCard).join('') : empty('فیلمی با این مشخصات وجود ندارد؛ یک فیلم تازه اضافه کن.');
}
function badge(status) { return `<span class="badge ${['sent', 'published', 'demo_sent'].includes(status) ? 'green' : ['failed', 'unknown'].includes(status) ? 'red' : status === 'queued' ? 'amber' : 'neutral'}">${esc(labels[status] || status)}</span>`; }
function render() {
  $('#demo-banner').hidden = !state.demo;
  $('#workspace-status').textContent = state.demo ? 'محیط نمایشی · ارسال خاموش' : state.running ? 'دریافت پیام فعال است' : 'ربات متوقف است';
  $('#connection').innerHTML = `<i></i>${state.demo ? 'حالت نمایشی' : state.running ? 'ربات در حال اجرا' : 'ربات خاموش است'}`;
  $('#connection').classList.toggle('online', state.running);
  $('#connect-button').innerHTML = icon('link') + (state.demo ? 'اتصال ربات' : state.running ? 'توقف ربات' : 'اتصال و اجرا');
  $('#nav-movies').textContent = num(state.stats.movies); $('#nav-queue').textContent = num(state.stats.queued);
  $('#stats').innerHTML = [
    ['فیلم در کتابخانه', state.stats.movies, 'film', `${num(state.movies.filter(m => m.status === 'draft').length)} فیلم در انتظار آماده‌سازی`],
    ['کاربر ربات', state.stats.users, 'users', 'کاربران ثبت‌شده در پیام خصوصی ربات'],
    ['ارسال فایل موفق', state.stats.downloads, 'down', 'تعداد تحویل فایل توسط API تلگرام'],
    ['پست منتشرشده', state.stats.posts, 'send', `${num(state.stats.queued)} انتشار در صف زمان‌بندی`]
  ].map(([label, value, symbol, hint]) => `<article class="stat-card"><div><span>${label}</span><b>${num(value)}</b></div><div class="stat-icon">${icon(symbol)}</div><small>${hint}</small></article>`).join('');
  $('#recent-movies').innerHTML = state.movies.length ? state.movies.slice(0, 3).map(movieCard).join('') : empty('کتابخانه هنوز خالی است. اولین فیلم را اضافه کن.');
  $('#activity').innerHTML = state.events.length ? state.events.slice(0, 4).map(e => `<div class="activity-row"><span class="activity-icon">${e.type === 'error' ? '!' : e.type === 'publish' ? '↗' : '✓'}</span><div><p>${esc(e.message)}</p><small>${date(e.at)}</small></div></div>`).join('') : empty('هنوز فعالیتی ثبت نشده؛ با افزودن فیلم شروع کن.', '◷');
  renderLibrary();
  $('#queue-status').textContent = state.demo ? 'فقط شبیه‌سازی انتشار' : state.running ? 'صف فعال است' : 'ربات متوقف؛ صف اجرا نمی‌شود';
  $('#queue-body').innerHTML = state.jobs.length ? state.jobs.map(j => `<tr><td>${esc(state.movies.find(m => m.id === j.movieId)?.title || 'فیلم حذف‌شده')}</td><td>${date(j.runAt)}</td><td>${badge(j.status)}</td><td class="table-note">${esc(j.error || (j.status === 'demo_sent' ? 'هیچ پیام واقعی ارسال نشد.' : j.messageId ? `شناسه پست: ${j.messageId}` : '—'))}</td><td>${j.status === 'queued' ? `<button class="table-action" data-action="cancel-job" data-id="${j.id}">لغو انتشار</button>` : ['failed', 'unknown'].includes(j.status) ? `<button class="table-action" data-action="retry-job" data-id="${j.id}">تلاش دوباره</button>` : '—'}</td></tr>`).join('') : '<tr><td colspan="5">هنوز انتشاری در صف نیست؛ از کتابخانه یک فیلم را برای انتشار انتخاب کن.</td></tr>';
  $('#users-count').textContent = num(state.stats.users) + ' کاربر';
  $('#users-body').innerHTML = state.users.length ? state.users.map(u => `<tr><td>${esc(u.name)}</td><td dir="ltr">${esc(u.id)}</td><td>${num(u.downloads)}</td><td>${date(u.lastSeen)}</td><td>${badge(u.blocked ? 'failed' : 'published').replace(u.blocked ? 'ناموفق' : 'منتشرشده', u.blocked ? 'مسدود' : 'فعال')}</td><td><button class="table-action" data-action="toggle-user" data-id="${esc(u.id)}">${u.blocked ? 'رفع مسدودی' : 'مسدود کردن'}</button></td></tr>`).join('') : '<tr><td colspan="6">پس از شروع ربات توسط کاربران، این بخش پر می‌شود.</td></tr>';
  $('#inbox-list').innerHTML = state.inbox.length ? state.inbox.map(f => `<article class="inbox-card"><b>${esc(f.name)}</b><p>${esc({ photo: 'پوستر / عکس', document: 'فایل', video: 'ویدیو' }[f.type])} · ${num(f.size / 1048576)} مگابایت · ${date(f.at)}</p><code>${esc(f.fileId)}</code><button class="button subtle" data-action="use-file" data-id="${f.id}">${f.type === 'photo' ? 'استفاده به‌عنوان پوستر' : 'ساخت فیلم از این فایل'}</button></article>`).join('') : empty('هنوز فایلی دریافت نشده. پس از اتصال، مدیر مجاز فایل را برای ربات بفرستد.', '⇩');
}
async function refresh() { if (refreshing) return; refreshing = true; try { state = await api('/state'); render(); } finally { refreshing = false; } }
function showView(next) {
  if (!views[next]) next = 'overview'; view = next;
  document.querySelectorAll('[data-section]').forEach(el => { el.hidden = el.dataset.section !== view; });
  document.querySelectorAll('[data-view]').forEach(el => el.classList.toggle('active', el.dataset.view === view));
  $('#page-title').textContent = views[view][0]; $('#breadcrumb-title').textContent = views[view][0]; $('#page-description').textContent = views[view][1];
  if (view === 'channels') fillChannels(); if (view === 'settings') fillSettings();
  if (location.hash !== '#' + view) history.replaceState(null, '', '#' + view);
}
function fillChannels() {
  $('#publish-channel').value = state.settings.publishChannel; $('#force-join').checked = state.settings.forceJoin;
  $('#channel-rows').replaceChildren(); state.settings.channels.forEach(addChannelRow);
}
function addChannelRow(channel = {}) {
  const row = document.createElement('div'); row.className = 'channel-row'; row.dataset.id = channel.id || '';
  row.innerHTML = `<label>نام نمایشی<input name="channelTitle" value="${esc(channel.title || '')}" required maxlength="70" placeholder="کانال اصلی یا حامی"></label><label>شناسهٔ کانال<input name="channelId" dir="ltr" value="${esc(channel.chatId || '')}" required maxlength="50" placeholder="@channel یا -100…"></label><label>لینک عضویت<input name="channelUrl" dir="ltr" value="${esc(channel.inviteUrl || '')}" required type="url" maxlength="250" placeholder="https://t.me/…"></label><button class="remove-channel" type="button" aria-label="حذف کانال">×</button>`;
  row.querySelector('button').addEventListener('click', () => row.remove()); $('#channel-rows').append(row);
}
function fillSettings() { $('#brand-input').value = state.settings.brand; $('#username-input').value = state.settings.botUsername; $('#welcome-input').value = state.settings.welcome; }
function openMovie(movie = {}) {
  $('#movie-form').reset(); $('#movie-id').value = movie.id || ''; $('#movie-dialog-title').textContent = movie.id ? 'ویرایش فیلم' : 'افزودن فیلم جدید';
  for (const [key, field] of Object.entries({ title: 'title', year: 'year', genre: 'genre', quality: 'quality', poster: 'poster', fileId: 'file', description: 'description', fileType: 'type' })) $('#movie-' + field).value = movie[key] || (key === 'fileType' ? 'document' : '');
  $('#movie-dialog').showModal();
}
function openPublish(movie) {
  $('#publish-form').reset(); $('#publish-id').value = movie.id; $('#schedule-field').hidden = true; $('#schedule-at').required = false;
  $('#post-preview').innerHTML = `<div class="telegram-preview"><div class="telegram-bubble"><img src="${esc(poster(movie))}" alt="پوستر"><h3>🎬 ${esc(movie.title)}</h3><p>${esc([movie.year, movie.genre, movie.quality].filter(Boolean).join(' · '))}</p><p>${esc(movie.description)}</p></div><div class="telegram-download">📥 دانلود از ربات</div><div class="preview-link">${state.demo ? 'پیش‌نمایش نمایشی؛ لینک فعال نیست' : esc(movie.deepLink || 'نام کاربری ربات هنوز تنظیم نشده')}</div></div>`;
  $('#publish-note').textContent = state.demo ? 'در حالت نمایشی فقط وضعیت صف تغییر می‌کند؛ هیچ پوستر یا پیامی ارسال نمی‌شود.' : `پس از تأیید، پوستر در ${state.settings.publishChannel || 'کانال تنظیم‌نشده'} منتشر می‌شود. برای اجرا، ربات باید فعال باشد.`;
  $('#publish-dialog').showModal();
}
document.addEventListener('error', e => { if (e.target.tagName === 'IMG' && !e.target.src.endsWith('/movie-assets/placeholder.svg')) e.target.src = '/movie-assets/placeholder.svg'; }, true);
document.addEventListener('click', e => {
  const close = e.target.closest('[data-close]'); if (close) { close.closest('dialog').close(); return; }
  const nav = e.target.closest('[data-view],[data-go]'); if (nav && state) { showView(nav.dataset.view || nav.dataset.go); return; }
  const button = e.target.closest('[data-action]'); if (!button || !state) return;
  const action = button.dataset.action, id = button.dataset.id;
  if (action === 'download-laptop') e.preventDefault();
  task(async () => {
    if (action === 'download-laptop') {
      const response = await fetch('/downloads/cinemanava-laptop.zip', { credentials: 'same-origin' });
      if (!response.ok || !response.headers.get('content-type')?.includes('application/zip')) throw Error('دریافت فایل از پنل ممکن نشد؛ متن خطا را بدون اطلاعات محرمانه بفرست.');
      const file = await response.blob(), url = URL.createObjectURL(file), link = document.createElement('a');
      link.href = url; link.download = 'cinemanava-laptop.zip'; document.body.append(link); link.click(); link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 60000);
      toast('اگر ذخیره شروع نشد، «روش جایگزین: دانلود در تب جدید» را بزن؛ پیش‌نمایش ممکن است دانلود خودکار را مسدود کند.');
    }
    if (action === 'setup') $('#setup-dialog').showModal();
    if (action === 'new-movie') openMovie();
    if (action === 'edit-movie') openMovie(state.movies.find(m => m.id === id));
    if (action === 'publish') openPublish(state.movies.find(m => m.id === id));
    if (action === 'delete-movie' && confirm('این فیلم از کتابخانه حذف شود؟ پست قبلی کانال خودکار حذف نمی‌شود.')) { await api('/movies/' + id, 'DELETE', {}); await refresh(); toast('فیلم از کتابخانه حذف شد.'); }
    if (action === 'connection') {
      if (state.demo) { $('#setup-dialog').showModal(); return; }
      await api('/connection', 'POST', { action: state.running ? 'stop' : 'start' }); await refresh(); toast(state.running ? 'ربات متصل شد؛ صف انتشار فعال است.' : 'ربات متوقف شد.');
    }
    if (action === 'refresh') { await refresh(); toast('اطلاعات به‌روزرسانی شد.'); }
    if (action === 'cancel-job') { await api('/jobs/' + id, 'POST', { action: 'cancel' }); await refresh(); }
    if (action === 'retry-job') {
      const job = state.jobs.find(j => j.id === id);
      if (job.status === 'unknown' && !confirm('ممکن است پست قبلاً ارسال شده باشد. کانال را بررسی کرده‌ای و خطر انتشار تکراری را می‌پذیری؟')) return;
      await api('/jobs/' + id, 'POST', { action: 'retry', confirmDuplicateRisk: true }); await refresh();
    }
    if (action === 'toggle-user') { const user = state.users.find(u => u.id === id); await api('/users/' + id, 'PUT', { blocked: !user.blocked }); await refresh(); }
    if (action === 'use-file') { const file = state.inbox.find(f => f.id === id); openMovie(file.type === 'photo' ? { poster: file.fileId } : { title: file.name.replace(/\.[^.]+$/, ''), fileId: file.fileId, fileType: file.type }); }
  }, button);
});
$('#add-channel').addEventListener('click', () => { if ($('#channel-rows').children.length >= 5) return toast('حداکثر پنج کانال مجاز است.', true); addChannelRow(); });
$('#movie-search').addEventListener('input', renderLibrary); $('#movie-filter').addEventListener('change', renderLibrary);
$('#movie-form').addEventListener('submit', e => { e.preventDefault(); task(async () => {
  const id = $('#movie-id').value;
  const movie = { title: $('#movie-title').value, year: $('#movie-year').value, genre: $('#movie-genre').value, quality: $('#movie-quality').value, description: $('#movie-description').value, poster: $('#movie-poster').value, fileId: $('#movie-file').value, fileType: $('#movie-type').value };
  await api('/movies' + (id ? '/' + id : ''), id ? 'PUT' : 'POST', movie); $('#movie-dialog').close(); await refresh(); toast('فیلم ذخیره شد؛ برای انتشار، دکمهٔ انتشار را بزن.');
}, e.submitter); });
$('#publish-now').addEventListener('change', () => { const scheduled = !$('#publish-now').checked; $('#schedule-field').hidden = !scheduled; $('#schedule-at').required = scheduled; });
$('#publish-form').addEventListener('submit', e => { e.preventDefault(); task(async () => {
  const runAt = $('#publish-now').checked ? null : new Date($('#schedule-at').value).toISOString();
  if (runAt && Date.parse(runAt) <= Date.now()) throw Error('زمان انتشار باید در آینده باشد.');
  await api('/movies/' + $('#publish-id').value + '/publish', 'POST', { runAt }); $('#publish-dialog').close(); await refresh(); toast(state.demo ? 'انتشار آزمایشی به صف اضافه شد؛ ارسال واقعی خاموش است.' : 'فیلم به صف انتشار اضافه شد.');
}, e.submitter); });
$('#channels-form').addEventListener('submit', e => { e.preventDefault(); task(async () => {
  const channels = [...document.querySelectorAll('.channel-row')].map(row => ({ id: row.dataset.id, title: row.querySelector('[name=channelTitle]').value, chatId: row.querySelector('[name=channelId]').value, inviteUrl: row.querySelector('[name=channelUrl]').value }));
  await api('/settings', 'PUT', { ...state.settings, publishChannel: $('#publish-channel').value, forceJoin: $('#force-join').checked, channels }); await refresh(); fillChannels(); toast('کانال‌ها ذخیره شدند؛ درخواست بعدی با تنظیمات جدید بررسی می‌شود.');
}, e.submitter); });
$('#settings-form').addEventListener('submit', e => { e.preventDefault(); task(async () => {
  await api('/settings', 'PUT', { ...state.settings, brand: $('#brand-input').value, botUsername: $('#username-input').value, welcome: $('#welcome-input').value }); await refresh(); fillSettings(); toast('تنظیمات ربات ذخیره شد.');
}, e.submitter); });
$('#login-form').addEventListener('submit', e => { e.preventDefault(); task(async () => {
  try { await api('/login', 'POST', { password: $('#password').value }); $('#password').value = ''; $('#login-error').textContent = ''; await boot(); }
  catch (error) { $('#login-error').textContent = error.message; }
}, e.submitter); });
$('#logout').addEventListener('click', () => task(async () => { if (state.demo) return toast('محیط نمایشی حساب خصوصی ندارد؛ اتصال واقعی از راهنمای راه‌اندازی انجام می‌شود.'); await api('/logout', 'POST', {}); $('#shell').hidden = true; $('#login-screen').hidden = false; }));
async function boot() {
  const auth = await api('/auth'); $('#login-screen').hidden = auth.authenticated; $('#shell').hidden = !auth.authenticated;
  if (!auth.authenticated) return;
  await refresh(); showView(location.hash.slice(1));
}
$('#today').textContent = new Date().toLocaleDateString('fa-IR', { day: 'numeric', month: 'long', year: 'numeric' });
boot().catch(e => { $('#login-screen').hidden = false; $('#login-error').textContent = 'دریافت پنل ممکن نشد: ' + e.message; });
setInterval(() => { if (state && !$('#shell').hidden && !document.querySelector('dialog[open]')) refresh().catch(() => {}); }, 10000);

fetch('/downloads/cinemanava-laptop.zip', { method: 'HEAD' }).then(r => { $('#laptop-download').hidden = !r.ok; }).catch(() => {});

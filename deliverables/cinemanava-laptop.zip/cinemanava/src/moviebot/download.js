const fs = require('node:fs');
const path = require('node:path');
// Only the sanitized, explicitly-built installer archive is public.
async function serveDownload(req, res, pathname, root) {
  if (pathname !== '/downloads/cinemanava-laptop.zip') return false;
  if (!['GET', 'HEAD'].includes(req.method)) { res.writeHead(405, { Allow: 'GET, HEAD' }); res.end(); return true; }
  const file = path.join(root, 'deliverables', 'cinemanava-laptop.zip');
  let info;
  try { info = await fs.promises.stat(file); if (!info.isFile()) throw Error('missing'); }
  catch { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('Download not available on this installation'); return true; }
  res.writeHead(200, { 'Content-Type': 'application/zip', 'Content-Disposition': 'attachment; filename="cinemanava-laptop.zip"', 'Content-Length': info.size, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  if (req.method === 'HEAD') { res.end(); return true; }
  const stream = fs.createReadStream(file);
  stream.on('error', () => res.destroy());
  res.on('close', () => stream.destroy());
  stream.pipe(res);
  return true;
}
module.exports = { serveDownload };

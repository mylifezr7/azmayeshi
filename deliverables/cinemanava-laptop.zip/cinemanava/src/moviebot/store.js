const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const id = () => crypto.randomBytes(9).toString('hex');
function seed(demo) {
  return {
    version: 1,
    settings: { brand: 'سینمانوا', botUsername: '', publishChannel: '', forceJoin: true,
      welcome: 'به سینمانوا خوش آمدی. برای دریافت فایل، ابتدا در کانال‌های زیر عضو شو.', channels: [] },
    movies: demo ? [
      { id: 'demo_dawn', title: 'سفر به سپیده', year: '2025', genre: 'ماجراجویی', quality: '1080p', description: 'یک سفر تازه، در جست‌وجوی روشنایی. فیلم و پوستر صرفاً نمونهٔ نمایشی هستند.', poster: '/movie-assets/dawn.svg', fileId: '', fileType: 'document', status: 'draft', downloads: 0 },
      { id: 'demo_orbit', title: 'مدار خاموش', year: '2024', genre: 'علمی‌تخیلی', quality: '1080p', description: 'آن سوی سکوت، داستانی منتظر شنیده‌شدن است. محتوای نمونهٔ پنل.', poster: '/movie-assets/orbit.svg', fileId: '', fileType: 'document', status: 'draft', downloads: 0 },
      { id: 'demo_rain', title: 'پس از باران', year: '2025', genre: 'درام', quality: '720p', description: 'روایتی از شروع دوباره. محتوای نمونهٔ پنل.', poster: '/movie-assets/rain.svg', fileId: '', fileType: 'document', status: 'draft', downloads: 0 }
    ].map(m => ({ ...m, createdAt: new Date().toISOString() })) : [],
    users: [], inbox: [], jobs: [], events: [], processedUpdates: [], offset: 0
  };
}
class Store {
  constructor(file, demo = false) {
    this.file = file;
    if (fs.existsSync(file)) {
      this.data = JSON.parse(fs.readFileSync(file, 'utf8'));
      if (this.data.version !== 1 || !Array.isArray(this.data.movies)) throw Error('ساختار فایل داده نامعتبر است؛ فایل را بدون نسخه پشتیبان تغییر ندهید.');
    } else this.data = seed(demo);
    for (const job of this.data.jobs) if (job.status === 'sending') { job.status = 'unknown'; job.error = 'سرویس هنگام ارسال متوقف شده؛ قبل از تلاش دوباره کانال را بررسی کن.'; }
    this.save();
  }
  save() {
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    const tmp = this.file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(this.data, null, 2), { mode: 0o600 });
    fs.renameSync(tmp, this.file);
  }
  event(type, message, extra = {}) {
    this.data.events.unshift({ id: id(), type, message, at: new Date().toISOString(), ...extra });
    this.data.events = this.data.events.slice(0, 300);
    this.save();
  }
}
module.exports = { Store, id, seed };

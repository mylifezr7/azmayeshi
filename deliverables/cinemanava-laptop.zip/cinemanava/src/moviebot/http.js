const crypto = require('node:crypto');
const { id } = require('./store');
const { livePoster } = require('./service');
function json(res, status, data, headers = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(JSON.stringify(data));
}
function fail(message, status = 400) { const e = Error(message); e.status = status; throw e; }
function text(value, max = 500) { if (typeof value !== 'string' || value.length > max) fail('طول یا نوع متن معتبر نیست.'); return value.trim(); }
function channelId(value) { return /^(@[a-zA-Z][a-zA-Z0-9_]{4,31}|-100\d{5,20})$/.test(value); }
function telegramUrl(value) { try { const u = new URL(value); return u.protocol === 'https:' && ['t.me', 'telegram.me'].includes(u.hostname) && !u.username && !u.password && u.pathname.length > 1; } catch { return false; } }
async function body(req) {
  if (!(req.headers['content-type'] || '').startsWith('application/json')) fail('نوع درخواست باید JSON باشد.', 415);
  let value = ''; for await (const chunk of req) { value += chunk; if (Buffer.byteLength(value) > 65536) fail('درخواست بیش از حد بزرگ است.', 413); }
  try { const result = JSON.parse(value || '{}'); if (!result || Array.isArray(result) || typeof result !== 'object') fail('درخواست نامعتبر است.'); return result; } catch { fail('ساختار JSON معتبر نیست.'); }
}
function createHandler(store, bot, { password = '', secureCookies = false } = {}) {
  const sessions = new Map(), failures = new Map(), salt = crypto.randomBytes(16);
  const hash = password ? crypto.scryptSync(password, salt, 64) : null;
  function session(req) {
    if (bot.demo) return true;
    const cookie = /(?:^|;\s*)moviebot_session=([a-f0-9]{64})(?:;|$)/.exec(req.headers.cookie || '');
    const key = cookie?.[1]; if (!key) return false;
    if ((sessions.get(key) || 0) <= Date.now()) { sessions.delete(key); return false; }
    return true;
  }
  function csrf(req) {
    if (req.headers['x-moviebot-admin'] !== '1') fail('درخواست از پنل معتبر نیست.', 403);
    if (req.headers.origin) {
      let host; try { host = new URL(req.headers.origin).host; } catch { fail('Origin نامعتبر است.', 403); }
      const allowed = [req.headers.host, req.headers['x-forwarded-host']?.split(',')[0].trim()];
      if (!allowed.includes(host)) fail('درخواست میان‌سایتی مجاز نیست.', 403);
    }
  }
  return async function handle(req, res, url) {
    if (!url.pathname.startsWith('/api/moviebot/')) return false;
    try {
      const route = url.pathname.slice('/api/moviebot'.length), method = req.method;
      if (method !== 'GET') csrf(req);
      if (route === '/auth' && method === 'GET') { json(res, 200, { demo: bot.demo, authenticated: session(req) }); return true; }
      if (route === '/login' && method === 'POST') {
        const input = await body(req);
        const key = req.socket.remoteAddress || 'unknown';
        const record = failures.get(key) || { count: 0, until: Date.now() + 15 * 60000 };
        if (record.until < Date.now()) { record.count = 0; record.until = Date.now() + 15 * 60000; }
        if (record.count >= 5) fail('تعداد تلاش زیاد است؛ ۱۵ دقیقه دیگر امتحان کن.', 429);
        if (!bot.demo && (!hash || typeof input.password !== 'string' || input.password.length > 500 || !crypto.timingSafeEqual(hash, crypto.scryptSync(input.password, salt, 64)))) {
          record.count++; failures.set(key, record); fail('رمز ورود درست نیست.', 401);
        }
        failures.delete(key);
        const token = crypto.randomBytes(32).toString('hex');
        for (const [key, expiry] of sessions) if (expiry < Date.now()) sessions.delete(key);
        if (sessions.size > 100) sessions.delete(sessions.keys().next().value);
        sessions.set(token, Date.now() + 12 * 3600000);
        const secure = secureCookies || req.headers['x-forwarded-proto'] === 'https';
        json(res, 200, { ok: true }, { 'Set-Cookie': `moviebot_session=${token}; HttpOnly; SameSite=Strict; Path=/api/moviebot; Max-Age=43200${secure ? '; Secure' : ''}` }); return true;
      }
      if (!session(req)) fail('ابتدا وارد پنل شو.', 401);
      if (route === '/logout' && method === 'POST') {
        const match = /moviebot_session=([a-f0-9]{64})/.exec(req.headers.cookie || ''); if (match) sessions.delete(match[1]);
        json(res, 200, { ok: true }, { 'Set-Cookie': 'moviebot_session=; HttpOnly; SameSite=Strict; Path=/api/moviebot; Max-Age=0' }); return true;
      }
      if (route === '/state' && method === 'GET') {
        const d = store.data;
        json(res, 200, { ...bot.state(), settings: d.settings, movies: d.movies.map(m => ({ ...m, deepLink: bot.deepLink(m.id) })), jobs: d.jobs.slice(0, 100), users: d.users.slice(-500).reverse(), inbox: d.inbox, events: d.events.slice(0, 100), stats: { movies: d.movies.length, users: d.users.length, downloads: d.users.reduce((s, u) => s + (u.downloads || 0), 0), posts: d.jobs.filter(j => j.status === 'sent').length, queued: d.jobs.filter(j => j.status === 'queued').length }, serverTime: new Date().toISOString() }); return true;
      }
      if (route === '/backup' && method === 'GET') { json(res, 200, store.data, { 'Content-Disposition': 'attachment; filename="cinemanava-backup.json"' }); return true; }
      if (route === '/settings' && method === 'PUT') {
        const input = await body(req), s = store.data.settings;
        const next = { brand: text(input.brand, 60), botUsername: text(input.botUsername || '', 32).replace(/^@/, ''), publishChannel: text(input.publishChannel || '', 50), welcome: text(input.welcome, 1500), forceJoin: input.forceJoin === true, channels: input.channels };
        if (!next.brand || !next.welcome) fail('نام مجموعه و پیام خوشامد لازم است.');
        if (next.botUsername && !/^[a-zA-Z][a-zA-Z0-9_]{4,31}$/.test(next.botUsername)) fail('نام کاربری ربات معتبر نیست.');
        if (next.publishChannel && !channelId(next.publishChannel)) fail('کانال انتشار باید @username یا شناسه عددی -100… باشد.');
        if (!Array.isArray(next.channels) || next.channels.length > 5) fail('حداکثر پنج کانال عضویت مجاز است.');
        next.channels = next.channels.map(c => ({ id: c.id && /^[a-f0-9]{18}$/.test(c.id) ? c.id : id(), title: text(c.title, 70), chatId: text(c.chatId, 50), inviteUrl: text(c.inviteUrl, 250) }));
        for (const c of next.channels) if (!c.title || !channelId(c.chatId) || !telegramUrl(c.inviteUrl)) fail('نام، شناسه کانال و لینک عضویت HTTPS تلگرام را درست وارد کن.');
        if (new Set(next.channels.map(c => c.chatId.toLowerCase())).size !== next.channels.length) fail('کانال تکراری است.');
        if (next.forceJoin && !next.channels.length) fail('برای عضویت اجباری حداقل یک کانال اضافه کن.');
        Object.assign(s, next); store.event('settings', 'تنظیمات کانال‌ها و عضویت به‌روزرسانی شد.'); json(res, 200, { ok: true }); return true;
      }
      if (route === '/connection' && method === 'POST') {
        const input = await body(req); const state = input.action === 'start' ? await bot.start() : input.action === 'stop' ? bot.stop() : fail('عملیات نامعتبر است.');
        json(res, 200, state); return true;
      }
      const movieMatch = /^\/movies(?:\/([a-zA-Z0-9_-]{1,50}))?$/.exec(route);
      if (movieMatch && ['POST', 'PUT', 'DELETE'].includes(method)) {
        const movieId = movieMatch[1], movie = store.data.movies.find(m => m.id === movieId);
        if (method !== 'POST' && !movie) fail('فیلم پیدا نشد.', 404);
        if (method === 'DELETE') {
          if (store.data.jobs.some(j => j.movieId === movieId && j.status === 'sending')) fail('ارسال در جریان است؛ بعداً امتحان کن.');
          store.data.movies = store.data.movies.filter(m => m.id !== movieId);
          for (const j of store.data.jobs) if (j.movieId === movieId && j.status === 'queued') j.status = 'cancelled';
          store.event('movie', `فیلم «${movie.title}» از کتابخانه حذف شد؛ پست قبلی کانال خودکار حذف نمی‌شود.`); json(res, 200, { ok: true }); return true;
        }
        const input = await body(req);
        const value = { title: text(input.title, 120), year: text(input.year || '', 4), genre: text(input.genre || '', 60), quality: text(input.quality || '', 40), description: text(input.description || '', 700), poster: text(input.poster || '', 1500), fileId: text(input.fileId || '', 300), fileType: input.fileType === 'video' ? 'video' : 'document' };
        if (!value.title) fail('نام فیلم لازم است.');
        if (value.year && !/^\d{4}$/.test(value.year)) fail('سال باید چهاررقمی باشد.');
        if (value.poster && !livePoster(value.poster) && !(bot.demo && /^\/movie-assets\/[a-z]+\.svg$/.test(value.poster))) fail('پوستر باید لینک HTTPS یا file_id تلگرام باشد.');
        if (value.fileId && !/^[a-zA-Z0-9_-]{10,300}$/.test(value.fileId)) fail('file_id فایل معتبر نیست.');
        if (movie && store.data.jobs.some(j => j.movieId === movie.id && j.status === 'sending')) fail('هنگام ارسال نمی‌توان فیلم را ویرایش کرد.');
        let item;
        if (method === 'POST') { if (store.data.movies.length >= 5000) fail('ظرفیت نسخه اولیه ۵۰۰۰ فیلم است.'); item = { id: id(), ...value, status: 'draft', downloads: 0, createdAt: new Date().toISOString() }; store.data.movies.unshift(item); }
        else { Object.assign(movie, value); item = movie; }
        store.event('movie', `فیلم «${item.title}» ذخیره شد.`); json(res, 200, { movie: item }); return true;
      }
      const publish = /^\/movies\/([a-zA-Z0-9_-]{1,50})\/publish$/.exec(route);
      if (publish && method === 'POST') { const input = await body(req); json(res, 200, { job: bot.queue(publish[1], input.runAt) }); return true; }
      const jobMatch = /^\/jobs\/([a-f0-9]{18})$/.exec(route);
      if (jobMatch && method === 'POST') {
        const input = await body(req), job = store.data.jobs.find(j => j.id === jobMatch[1]); if (!job) fail('انتشار پیدا نشد.', 404);
        if (input.action === 'cancel' && job.status === 'queued') { job.status = 'cancelled'; const movie = store.data.movies.find(m => m.id === job.movieId); if (movie) movie.status = job.previousMovieStatus || 'draft'; }
        else if (input.action === 'retry' && ['failed', 'unknown'].includes(job.status)) {
          const movie = store.data.movies.find(m => m.id === job.movieId); if (!movie) fail('فیلم حذف شده است.'); bot.validatePublish(movie);
          if (store.data.jobs.some(j => j.id !== job.id && j.movieId === job.movieId && ['queued', 'sending'].includes(j.status))) fail('این فیلم یک انتشار دیگر در صف دارد.');
          if (job.status === 'unknown' && input.confirmDuplicateRisk !== true) fail('اول کانال را بررسی کن؛ ارسال مجدد ممکن است پست تکراری بسازد.');
          job.status = 'queued'; movie.status = 'queued'; job.runAt = new Date().toISOString(); delete job.error;
        } else fail('این عملیات برای وضعیت فعلی مجاز نیست.');
        store.save(); json(res, 200, { ok: true }); return true;
      }
      const userMatch = /^\/users\/(\d{1,20})$/.exec(route);
      if (userMatch && method === 'PUT') { const input = await body(req), user = store.data.users.find(u => u.id === userMatch[1]); if (!user) fail('کاربر پیدا نشد.', 404); user.blocked = input.blocked === true; store.save(); json(res, 200, { ok: true }); return true; }
      json(res, 404, { error: 'مسیر پیدا نشد.' }); return true;
    } catch (e) { json(res, e.status || 400, { error: e.message || 'خطای غیرمنتظره' }); return true; }
  };
}
module.exports = { createHandler, channelId, telegramUrl };

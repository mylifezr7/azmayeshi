class TelegramError extends Error {
  constructor(message, uncertain = false) { super(message); this.uncertain = uncertain; }
}
class Telegram {
  constructor(token) { this.token = token; }
  async call(method, body = {}, timeout = 35000) {
    let response;
    try {
      response = await fetch(`https://api.telegram.org/bot${this.token}/${method}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body), signal: AbortSignal.timeout(timeout)
      });
    } catch { throw new TelegramError('ارتباط با تلگرام برقرار نشد یا زمان پاسخ تمام شد؛ نتیجه ارسال ممکن است نامشخص باشد.', true); }
    let result;
    try { result = await response.json(); } catch { throw new TelegramError('پاسخ نامعتبر تلگرام؛ نتیجه درخواست نامشخص است.', true); }
    if (!result.ok) throw new TelegramError(`تلگرام: ${String(result.description || response.status).replaceAll(this.token, '[REDACTED]')}`);
    return result.result;
  }
}
const isMember = member => ['creator', 'administrator', 'member'].includes(member?.status) || (member?.status === 'restricted' && member.is_member === true);
module.exports = { Telegram, TelegramError, isMember };

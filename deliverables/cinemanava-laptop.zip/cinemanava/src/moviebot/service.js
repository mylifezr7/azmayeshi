const { id } = require('./store');
const { isMember } = require('./telegram');
const iso = () => new Date().toISOString();
function caption(movie) {
  return [`🎬 ${movie.title}`, [movie.year, movie.genre, movie.quality].filter(Boolean).join(' · '), movie.description || '', '👇 دریافت فایل از ربات'].filter(Boolean).join('\n\n').slice(0, 1024);
}
function livePoster(value) { return /^[A-Za-z0-9_-]{15,300}$/.test(value) || /^https:\/\/[^\s]+$/i.test(value); }
class MovieBot {
  constructor(store, api, { demo = false, configured = false, adminIds = [] } = {}) {
    this.store = store; this.api = api; this.demo = demo; this.configured = configured;
    this.adminIds = new Set(adminIds.map(String)); this.running = false; this.generation = 0;
    this.busy = false; this.lastError = null; this.lastPollAt = null;
    this.timer = setInterval(() => this.tick().catch(() => {}), 3000); this.timer.unref();
  }
  state() { return { demo: this.demo, configured: this.configured, running: this.running, lastError: this.lastError, lastPollAt: this.lastPollAt, adminUploadConfigured: this.adminIds.size > 0 }; }
  deepLink(movieId) {
    const username = this.store.data.settings.botUsername;
    return username ? `https://t.me/${username}?start=m_${movieId}` : null;
  }
  validatePublish(movie) {
    const s = this.store.data.settings;
    if (!this.demo && !this.configured) throw Error('توکن ربات و رمز امن پنل باید در محیط سرور تنظیم شوند.');
    if (!this.demo && (!s.botUsername || !s.publishChannel)) throw Error('نام کاربری ربات و کانال انتشار را تنظیم کن.');
    if (!this.demo && (!movie.fileId || !livePoster(movie.poster))) throw Error('پوستر HTTPS یا file_id تصویر و file_id فایل فیلم لازم است.');
    if (!this.demo && s.forceJoin && !s.channels.length) throw Error('حداقل یک کانال عضویت تعیین کن یا عضویت اجباری را خاموش کن.');
  }
  queue(movieId, runAt) {
    const movie = this.store.data.movies.find(m => m.id === movieId);
    if (!movie) throw Error('فیلم پیدا نشد.');
    this.validatePublish(movie);
    if (this.store.data.jobs.some(j => j.movieId === movieId && ['queued', 'sending'].includes(j.status))) throw Error('این فیلم یک انتشار در صف دارد.');
    const time = runAt ? new Date(runAt) : new Date();
    if (!Number.isFinite(time.getTime())) throw Error('زمان انتشار معتبر نیست.');
    const job = { id: id(), movieId, runAt: time.toISOString(), status: 'queued', previousMovieStatus: movie.status, createdAt: iso() };
    this.store.data.jobs.unshift(job); movie.status = 'queued'; this.store.save();
    return job;
  }
  async tick() {
    if (this.busy || (!this.demo && !this.running)) return;
    this.busy = true;
    try {
      const job = this.store.data.jobs.find(j => j.status === 'queued' && Date.parse(j.runAt) <= Date.now());
      if (!job) return;
      const movie = this.store.data.movies.find(m => m.id === job.movieId);
      if (!movie) { job.status = 'failed'; job.error = 'فیلم حذف شده است.'; this.store.save(); return; }
      job.status = 'sending'; this.store.save();
      try {
        this.validatePublish(movie);
        if (this.demo) {
          job.status = 'demo_sent'; movie.status = 'demo_published'; job.sentAt = iso();
          this.store.event('demo', `پیش‌نمایش انتشار «${movie.title}»؛ هیچ پیامی به تلگرام ارسال نشد.`); return;
        }
        const sent = await this.api.call('sendPhoto', {
          chat_id: this.store.data.settings.publishChannel, photo: movie.poster, caption: caption(movie),
          reply_markup: { inline_keyboard: [[{ text: '📥 دانلود از ربات', url: this.deepLink(movie.id) }]] }
        });
        job.status = 'sent'; job.messageId = sent.message_id; job.chatId = sent.chat.id; job.sentAt = iso(); movie.status = 'published';
        this.store.event('publish', `پوستر «${movie.title}» در کانال منتشر شد.`, { movieId: movie.id });
      } catch (e) {
        job.status = e.uncertain ? 'unknown' : 'failed'; job.error = e.message; movie.status = job.previousMovieStatus || 'draft';
        this.store.event('error', `انتشار «${movie.title}»: ${e.message}`);
      } finally { this.store.save(); }
    } finally { this.busy = false; }
  }
  async start() {
    if (this.demo) throw Error('حالت نمایشی به تلگرام متصل نمی‌شود.');
    if (!this.configured) throw Error('TELEGRAM_BOT_TOKEN و MOVIEBOT_ADMIN_PASSWORD را در محیط سرور تنظیم کن.');
    if (this.running) return this.state();
    const me = await this.api.call('getMe');
    const hook = await this.api.call('getWebhookInfo');
    if (hook.url) throw Error('این ربات وب‌هوک فعال دارد؛ پیش از استفاده از polling، اتصال قبلی را با بررسی خودت غیرفعال کن.');
    this.store.data.settings.botUsername = me.username; this.store.save();
    this.running = true; this.lastError = null; const generation = ++this.generation;
    this.store.event('system', 'ربات و صف انتشار فعال شدند.');
    this.poll(generation).catch(e => { this.lastError = e.message; this.running = false; });
    return this.state();
  }
  stop() { this.running = false; this.generation++; this.store.event('system', 'دریافت پیام و شروع انتشارهای جدید متوقف شد؛ درخواست در حال ارسال ممکن است تکمیل شود.'); return this.state(); }
  async poll(generation) {
    while (this.running && generation === this.generation) {
      try {
        const updates = await this.api.call('getUpdates', { offset: this.store.data.offset, timeout: 25, allowed_updates: ['message', 'callback_query'] });
        this.lastPollAt = iso(); this.lastError = null;
        for (const update of updates) {
          if (!this.running || generation !== this.generation) return;
          await this.handle(update);
          this.store.data.offset = update.update_id + 1; this.store.save();
        }
      } catch (e) {
        this.lastError = e.message;
        this.store.event('error', `دریافت پیام: ${e.message}`);
        await new Promise(resolve => { const t = setTimeout(resolve, 5000); t.unref(); });
      }
    }
  }
  async joined(userId) {
    const s = this.store.data.settings;
    if (!s.forceJoin) return true;
    if (!s.channels.length) return false;
    for (const channel of s.channels) {
      try { if (!isMember(await this.api.call('getChatMember', { chat_id: channel.chatId, user_id: userId }))) return false; }
      catch (e) { this.store.event('error', `بررسی عضویت در «${channel.title}» ناموفق بود؛ فایل ارسال نشد. ${e.message}`); return false; } // Fail closed: never send the protected file on API failure.
    }
    return true;
  }
  async promptJoin(chatId, movieId) {
    const s = this.store.data.settings;
    const keyboard = s.channels.map(c => [{ text: `عضویت در ${c.title}`, url: c.inviteUrl }]);
    keyboard.push([{ text: '✅ عضو شدم؛ بررسی و دریافت', callback_data: `check:${movieId || 'home'}` }]);
    await this.api.call('sendMessage', { chat_id: chatId, text: s.welcome + (s.channels.length ? '' : '\nتنظیمات عضویت هنوز تکمیل نشده است؛ با مدیر تماس بگیر.'), reply_markup: { inline_keyboard: keyboard } });
  }
  async deliver(chatId, userId, movieId) {
    const movie = this.store.data.movies.find(m => m.id === movieId && m.status === 'published');
    if (!movie) return this.api.call('sendMessage', { chat_id: chatId, text: 'این فیلم هنوز منتشر نشده یا دیگر در دسترس نیست.' });
    if (!await this.joined(userId)) return this.promptJoin(chatId, movieId);
    await this.api.call(movie.fileType === 'video' ? 'sendVideo' : 'sendDocument', {
      chat_id: chatId, [movie.fileType === 'video' ? 'video' : 'document']: movie.fileId,
      caption: `🎬 ${movie.title}${movie.quality ? ' · ' + movie.quality : ''}`.slice(0, 1024)
    });
    movie.downloads = (movie.downloads || 0) + 1;
    const user = this.store.data.users.find(u => u.id === String(userId)); if (user) user.downloads++;
    this.store.event('download', `فایل «${movie.title}» به کاربر ارسال شد.`, { movieId, userId: String(userId) });
  }
  async catalog(chatId, userId, query = '') {
    if (!await this.joined(userId)) return this.promptJoin(chatId);
    const movies = this.store.data.movies.filter(m => m.status === 'published' && (!query || m.title.toLowerCase().includes(query.toLowerCase()))).slice(0, 15);
    await this.api.call('sendMessage', { chat_id: chatId, text: movies.length ? '🎬 برای دریافت، یک فیلم انتخاب کن. برای جست‌وجو نام فیلم را بنویس.' : 'فیلمی پیدا نشد؛ بعداً دوباره امتحان کن.', reply_markup: { inline_keyboard: movies.map(m => [{ text: m.title, callback_data: `movie:${m.id}` }]) } });
  }
  async handle(update) {
    if (this.demo) return;
    if (this.store.data.processedUpdates.includes(update.update_id)) return;
    const cb = update.callback_query, message = update.message || cb?.message, user = cb?.from || message?.from;
    if (!message || !user || message.chat?.type !== 'private' || user.is_bot) return;
    // Persist receipt before side effects; do not blindly resend after an uncertain API result.
    this.store.data.processedUpdates.push(update.update_id);
    this.store.data.processedUpdates = this.store.data.processedUpdates.slice(-1000);
    let record = this.store.data.users.find(u => u.id === String(user.id));
    if (!record) { record = { id: String(user.id), name: String(user.first_name || 'کاربر').slice(0, 100), joinedAt: iso(), lastSeen: iso(), downloads: 0, blocked: false }; this.store.data.users.push(record); }
    record.lastSeen = iso(); this.store.save();
    try {
      if (cb) { try { await this.api.call('answerCallbackQuery', { callback_query_id: cb.id }); } catch {} }
      if (record.blocked) return;
      const chatId = message.chat.id, text = message.text || '';
      if (text === '/id') return await this.api.call('sendMessage', { chat_id: chatId, text: `شناسه شما: ${user.id}` });
      const media = message.document || message.video || message.photo?.at(-1);
      if (media && this.adminIds.has(String(user.id))) {
        const type = message.photo ? 'photo' : message.video ? 'video' : 'document';
        this.store.data.inbox.unshift({ id: id(), fileId: media.file_id, type, name: media.file_name || message.caption || 'فایل تلگرام', size: media.file_size || 0, at: iso() });
        this.store.data.inbox = this.store.data.inbox.slice(0, 100); this.store.save();
        return await this.api.call('sendMessage', { chat_id: chatId, text: 'فایل ثبت شد. در پنل، بخش «فایل‌های دریافتی» می‌توانی آن را برای فیلم یا پوستر انتخاب کنی.' });
      }
      if (cb) {
        const match = /^(?:check|movie):([a-zA-Z0-9_-]{1,50})$/.exec(cb.data || '');
        if (match) return await (match[1] === 'home' ? this.catalog(chatId, user.id) : this.deliver(chatId, user.id, match[1]));
        return;
      }
      const start = /^\/start(?:@\w+)?(?:\s+m_([a-zA-Z0-9_-]{1,50}))?$/.exec(text);
      if (start?.[1]) return await this.deliver(chatId, user.id, start[1]);
      return await this.catalog(chatId, user.id, text.startsWith('/') ? '' : text.slice(0, 100));
    } catch (e) { this.store.event('error', `پردازش پیام: ${e.message}`); }
  }
  close() { this.running = false; this.generation++; clearInterval(this.timer); }
}
module.exports = { MovieBot, caption, livePoster };
